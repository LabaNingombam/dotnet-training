﻿namespace demo
{
    internal class MyDbContext
    {
    }
}