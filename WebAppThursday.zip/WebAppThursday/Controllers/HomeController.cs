﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebAppThursday.Models;

namespace WebAppThursday.Controllers
{
    //Preventing CSRF attacks by using the below attribute
  //  [ValidateAntiForgeryToken]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        //this method is an example for implementing Caching in .net core
     //   [ResponseCache(Duration = 30, Location = ResponseCacheLocation.Any)]
        public IActionResult Employees()
        {
            //create emp list Or get from a data source
            List<Employee> employees = new List<Employee>();
            Employee emp = new Employee(111, "Sivva", "Scheduler", DateTime.Now);
            employees.Add(emp);
            return View(emp);          

        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
