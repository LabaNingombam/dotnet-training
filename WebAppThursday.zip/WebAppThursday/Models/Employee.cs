﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppThursday.Models
{
    public class Employee
    {
        public int EmpId
        {
            get;
            set;
        }
        public string EmpName
        {
            get;
            set;
        }
        public string EmpDept
        {
            get;
            set;
        }

        public DateTime Datetime
        {
            get;
            set;
        }

        public Employee(int id, string name, string dept, DateTime date)

        {
            EmpId = id;
            EmpName = name;
            EmpDept = dept;
            Datetime = date;
        }

    }
}
