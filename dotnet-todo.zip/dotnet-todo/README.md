# dotnet-todo
A Simple ToDo List created in C#, donet-core and ef-core

Nuget Packages required:
1. dotnet add package McMaster.Extensions.CommandLineUtils 
2. dotnet add package Microsoft.EntityFrameworkCore.Sqlite
3. dotnet add package Microsoft.EntityFrameworkCore.Design


For EF Core Migrations:
1. dotnet ef migrations add 'migration name'
2. dotnet ef database update

To Generate Scripts:

1. dotnet ef migrations script

How to use:

1. dotnet run add "Todo1"
2. dotnet run list
3. dotnet run remove 1
