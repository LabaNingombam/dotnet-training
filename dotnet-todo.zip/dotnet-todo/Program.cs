﻿using McMaster.Extensions.CommandLineUtils;
using System;
using System.Threading.Tasks;

namespace ToDo
{
    class Program
    {
        static Task<int> Main(string[] args) => CommandLineApplication.ExecuteAsync<TodoCommands>(args);
    }
}
