﻿using McMaster.Extensions.CommandLineUtils;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToDo
{
    [Subcommand(typeof(AddCommand), typeof(ListCommand), typeof(RemoveCommand))]
    public class TodoCommands
    {
        public ToDoContext ToDoContext { get; }

        public TodoCommands()
        {
            ToDoContext = new ToDoContext();
            ToDoContext.Database.EnsureCreated();
        }

        public Task<int> OnExecute(CommandLineApplication application)
        {
            application.ShowHelp();
            return Task.FromResult(0);
        }
    }

    [Command("add")]
    public class AddCommand
    {
        public TodoCommands Parent { get; set; }

        [Argument(0, name: "Item name")]
        public string Name { get; set; }

        public async Task<int> OnExecuteAsync()
        {
            Parent.ToDoContext.Add(new Item { Name = Name });
            await Parent.ToDoContext.SaveChangesAsync();
            return 0;
        }
    }

    [Command("list")]
    public class ListCommand
    {
        public TodoCommands Parent { get; set; }

        public async Task<int> OnExecuteAsync()
        {
            var items = await Parent.ToDoContext.Items.ToListAsync();
            items.ForEach(System.Console.WriteLine);
            return 0;
        }
    }


    [Command("remove")]
    public class RemoveCommand
    {

        [Argument(0, name: "Item Id")]
        public int Id { get; set; }

        public TodoCommands Parent { get; set; }

        public async Task<int> OnExecuteAsync()
        {
            Parent.ToDoContext.Remove(new Item { Id = Id });
            await Parent.ToDoContext.SaveChangesAsync();
            return 0;
        }
    }
}
